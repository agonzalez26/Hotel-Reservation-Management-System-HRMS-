/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hrms.Model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Ejiroghene
 */
public class Application {

    private static boolean emp = true;
    private static String guestCount = "0";
    private static String roomCount = "0";
    private static List<String> chosenRooms = new ArrayList<String>();
    private static String guestFirstName=null;
    private static String guestLastName=null;
    private static String guestPhoneNumber=null;
    private static String guestEmailAddress=null;
    private static String guestAddress=null;
    private static int reservationNumber=0;
    private static HashMap hm = new HashMap();
    private static String startDate=null;
    private static String endDate = null;
    private static Reservation reservation = null;
    
    public void setEmp(boolean t) {
        emp = t;
    }

    public boolean getEmp() {
        return emp;
    }

    public void setGuestCount(String guestCount) {
        this.guestCount = guestCount;
    }

    public String getGuestCount() {
        return guestCount;
    }

    public void setRoomCount(String roomCount) {
        this.roomCount = roomCount;
    }

    public String getRoomCount() {
        return roomCount;
    }

    public void setChosenRooms(List<String> chosenRooms) {
        this.chosenRooms = chosenRooms;
    }

    public List<String> getChosenRooms() {
        return chosenRooms;
    }
    
    public void setFirstName(String firstName){
        this.guestFirstName=firstName;
    }
    
    public String getFirstName(){
        return guestFirstName;
    }
    
    public void setLastName(String lastName){
        this.guestLastName=lastName;
    }
    
    public String getLastName(){
        return guestLastName;
    }
    
    public void setEmailAddress(String emailAddress){
        this.guestEmailAddress=emailAddress;
    }
    
    public String getEmailAddress(){
        return guestEmailAddress;
    }
    
    public void setPhoneNumber(String phoneNumber){
        this.guestPhoneNumber=phoneNumber;
    }
    
    public String getPhoneNumber(){
        return guestPhoneNumber;
    }
    
    public void setAddress(String address){
        this.guestAddress=address;
    }
    
    public String getAddress(){
        return guestAddress;
    }
    
    public void setReservationNumber(int reservationNumber){
        this.reservationNumber=reservationNumber;
    }
    
    public int getReservationNumber(){
        return reservationNumber;
    }
    
     public void setMap(HashMap hm){
        this.hm = hm;
    }
    
    public HashMap getMap(){
        return hm;
    }
    
    public void setStartDate(String startDate){
        this.startDate=startDate;
    }
    
    public String getStartDate(){
        return startDate;
    }
    
    public void setEndDate(String endDate){
        this.endDate=endDate;
    }
    
    public String getEndDate(){
        return endDate;
    }
    
    public String getRoomString(){
        String roomString = "";
        for(int i=0; i<chosenRooms.size(); i++){
            String s = chosenRooms.get(i);
            if(s!=chosenRooms.get(0)){
                roomString += ", ";
            }
            int end = chosenRooms.size()-1;
            int ind = s.indexOf("m")+1;
            if(s==chosenRooms.get(end)){
                roomString += s.substring(ind);
            }else{
                roomString += s.substring(ind, ind+3);
            }
        }
        return roomString;
    }
    
   public int getAmenityCount(){
        int count = 0;
        for(String s: chosenRooms){
            List<String> selAmens;
            try{
                selAmens = (List<String>) hm.get(s);
                count += selAmens.size();
            }catch(NullPointerException e){
                        
           }
        }
        return count;
    }
    
   
   
   
    
}
